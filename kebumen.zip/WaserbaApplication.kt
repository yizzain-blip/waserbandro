package com.waserba.kebumen

import android.app.Application
import com.waserba.kebumen.utils.PreferencesManager
import com.waserba.kebumen.network.RetrofitClient

class WaserbaApplication : Application() {
    
    lateinit var preferencesManager: PreferencesManager
    
    companion object {
        lateinit var instance: WaserbaApplication
            private set
    }
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        
        // Initialize dependencies
        preferencesManager = PreferencesManager(this)
        
        // Initialize RetrofitClient with context for session token management
        RetrofitClient.init(this)
    }
}
