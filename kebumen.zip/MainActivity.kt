package com.waserba.kebumen

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.firebase.messaging.FirebaseMessaging
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.waserba.kebumen.network.RetrofitClient
import com.waserba.kebumen.service.FirebaseRealtimeEvents
import com.waserba.kebumen.ui.home.HomeFragment
import com.waserba.kebumen.utils.PreferencesManager
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 🔥 WAJIB: init retrofit context biar token jalan
        RetrofitClient.init(applicationContext)

        setContentView(R.layout.activity_main_with_nav)

        setupNavigation()
        tintNavigationIcons()
        syncFirebaseToken()

        // Register FCM broadcast receiver for real-time notifications (like fcm_handler.js)
        registerFcmReceiver()
        handleInitialIntent()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(fcmReceiver) } catch (_: Exception) {}
    }

    // =========================
    // FCM REAL-TIME BROADCAST RECEIVER (like handleFcmMessage in fcm_handler.js)
    // =========================
    private val fcmReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val jenis = intent.getStringExtra(FirebaseRealtimeEvents.EXTRA_KIND)
            val orderId = intent.getStringExtra(FirebaseRealtimeEvents.EXTRA_ORDER_ID)
            val message = intent.getStringExtra(FirebaseRealtimeEvents.EXTRA_MESSAGE)
            val dataJson = intent.getStringExtra(FirebaseRealtimeEvents.EXTRA_DATA)

            when (jenis) {
                FirebaseRealtimeEvents.JENIS_PESANAN_BARU -> {
                    showNewOrderDialogForKurir(orderId, dataJson, message)
                }
                FirebaseRealtimeEvents.JENIS_PESANAN_DIBATALKAN -> {
                    Toast.makeText(this@MainActivity, "🚫 $message", Toast.LENGTH_LONG).show()
                }
                FirebaseRealtimeEvents.JENIS_PESANAN_DIPROSES -> {
                    Toast.makeText(this@MainActivity, "✅ $message", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun registerFcmReceiver() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(fcmReceiver, IntentFilter(FirebaseRealtimeEvents.ACTION_ORDER_NOTIFICATION), RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(fcmReceiver, IntentFilter(FirebaseRealtimeEvents.ACTION_ORDER_NOTIFICATION))
        }
    }

    // Show new order dialog for kurir (matching showNewOrderPopup in kurir.js)
    private fun showNewOrderDialogForKurir(orderId: String?, dataJson: String?, message: String?) {
        if (orderId == null) return

        val gson = Gson()
        val orderData = if (dataJson != null) {
            try { gson.fromJson(dataJson, Map::class.java) as? Map<String, Any> } catch (_: Exception) { null }
        } else null

        val orderIdDisplay = orderId
        val pelanggan = orderData?.get("nama_pelanggan")?.toString() ?: message ?: "Pelanggan"
        val alamat = orderData?.get("alamat_pengiriman")?.toString() ?: "-"
        val produk = orderData?.get("daftar_produk")?.toString() ?: "-"
        val total = orderData?.get("total_harga")?.toString()?.toDoubleOrNull() ?: 0.0
        val ongkir = orderData?.get("ongkir")?.toString()?.toDoubleOrNull() ?: 0.0
        val jarak = orderData?.get("jarak_km")?.toString() ?: "-"

        val numberFormat = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID"))

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }

        // Order badge
        container.addView(TextView(this).apply {
            text = "📦 Pesanan Baru #$orderIdDisplay"
            textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, dp(16))
        })

        // Detail table (like showNewOrderPopup in kurir.js)
        val details = mapOf(
            "Pelanggan" to pelanggan,
            "Alamat" to alamat,
            "Produk" to produk,
            "Total" to "Rp ${numberFormat.format(total)}",
            "Ongkir" to "Rp ${numberFormat.format(ongkir)}",
            "Jarak" to "$jarak km"
        )

        details.forEach { (label, value) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(4), 0, dp(4))
            }
            row.addView(TextView(this).apply {
                text = "$label: "
                setTypeface(null, android.graphics.Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(TextView(this).apply {
                text = value
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
            })
            container.addView(row)
        }

        // Info text
        container.addView(TextView(this).apply {
            text = "\nKlik 'Terima' untuk mengambil pesanan ini"
            textSize = 12f
            setTextColor(android.graphics.Color.GRAY)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        })

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(container)
            .setPositiveButton("✅ TERIMA", null)
            .setNegativeButton("❌ TOLAK", null)
            .setNeutralButton("📝 CATATAN", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                // Accept order - call API matching ambilPesanan() in kurir.js
                acceptOrder(orderIdDisplay)
                dialog.dismiss()
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                // Reject order - call API matching tolakPesanan() in kurir.js
                rejectOrder(orderIdDisplay, "")
                dialog.dismiss()
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                // Reject with notes
                showRejectWithNotesDialog(orderIdDisplay)
                dialog.dismiss()
            }
        }

        dialog.show()
    }

    private fun acceptOrder(orderId: String) {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.apiService.acceptOrder(orderId)
                if (res.isSuccessful && res.body()?.status == "success") {
                    Toast.makeText(this@MainActivity, "✅ Pesanan #$orderId diterima!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Gagal menerima pesanan", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Accept order error", e)
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun rejectOrder(orderId: String, catatan: String) {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.apiService.respondOrder(
                    com.waserba.kebumen.model.CourierRespondRequest(
                        id_pesanan = orderId,
                        response = "reject",
                        catatan = catatan
                    )
                )
                if (res.isSuccessful) {
                    Toast.makeText(this@MainActivity, "Pesanan #$orderId ditolak", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Reject order error", e)
            }
        }
    }

    private fun showRejectWithNotesDialog(orderId: String) {
        val input = EditText(this).apply {
            hint = "Masukkan alasan penolakan..."
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Alasan Penolakan")
            .setView(input)
            .setPositiveButton("Kirim") { _, _ ->
                val catatan = input.text.toString()
                if (catatan.isNotEmpty()) {
                    rejectOrder(orderId, catatan)
                } else {
                    Toast.makeText(this, "Alasan harus diisi", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // =========================
    // NAVIGATION
    // =========================
    private fun setupNavigation() {

        findViewById<View>(R.id.logoContainer).setOnClickListener {
            loadFragment(HomeFragment())
            setActiveNav(R.id.navHome)
        }

        findViewById<View>(R.id.navHome).setOnClickListener {
            loadFragment(HomeFragment())
            setActiveNav(R.id.navHome)
        }

        findViewById<View>(R.id.navKategori).setOnClickListener {
            loadFragment(com.waserba.kebumen.ui.kategori.KategoriFragment())
            setActiveNav(R.id.navKategori)
        }

        findViewById<View>(R.id.navDashboard).setOnClickListener {
            loadFragment(com.waserba.kebumen.ui.dashboard.DashboardFragment())
            setActiveNav(R.id.navDashboard)
        }

        findViewById<View>(R.id.navChat).setOnClickListener {
            loadFragment(com.waserba.kebumen.ui.chat.ChatFragment())
            setActiveNav(R.id.navChat)
        }

        findViewById<View>(R.id.navAkun).setOnClickListener {
            loadFragment(com.waserba.kebumen.ui.akun.AkunFragment())
            setActiveNav(R.id.navAkun)
        }

        findViewById<View>(R.id.ordersButton).setOnClickListener {
            loadFragment(com.waserba.kebumen.ui.pesanan.PesananFragment())
        }

        findViewById<View>(R.id.cartButton).setOnClickListener {
            loadFragment(com.waserba.kebumen.ui.cart.CartFragment())
        }

        findViewById<View>(R.id.searchButton).setOnClickListener {
            showSearchDialog()
        }
    }

    private fun showSearchDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(18), dp(24), dp(8))
        }

        val title = TextView(this).apply {
            text = "Pencarian"
            textSize = 20f
            setTextColor(Color.BLACK)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val searchInput = EditText(this).apply {
            hint = "Masukkan kata kunci"
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }

        val radioGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val productOption = RadioButton(this).apply {
            id = View.generateViewId()
            text = "Produk"
            isChecked = true
        }

        val shopOption = RadioButton(this).apply {
            id = View.generateViewId()
            text = "Toko"
        }

        radioGroup.addView(productOption)
        radioGroup.addView(shopOption)

        container.addView(title)
        container.addView(searchInput, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) })
        container.addView(radioGroup, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(container)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Cari", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val query = searchInput.text.toString().trim()
                if (query.isEmpty()) {
                    searchInput.error = "Kata kunci wajib diisi"
                    return@setOnClickListener
                }

                val mode = if (radioGroup.checkedRadioButtonId == shopOption.id) {
                    com.waserba.kebumen.ui.search.SearchFragment.MODE_SHOP
                } else {
                    com.waserba.kebumen.ui.search.SearchFragment.MODE_PRODUCT
                }

                loadFragment(com.waserba.kebumen.ui.search.SearchFragment.newInstance(mode, query))
                dialog.dismiss()
            }
        }

        dialog.show()
    }

    // =========================
    // FRAGMENT HANDLER (FIX STACK BIAR GAK NUMPUK)
    // =========================
    private fun loadFragment(fragment: Fragment, addToBackStack: Boolean = true) {

        val transaction = supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)

        if (addToBackStack) {
            transaction.addToBackStack(null)
        }

        transaction.commit()
    }

    // =========================
    // ACTIVE NAV UI
    // =========================
    private fun setActiveNav(activeNavId: Int) {

        val navItems = listOf(
            R.id.navHome,
            R.id.navKategori,
            R.id.navDashboard,
            R.id.navChat,
            R.id.navAkun
        )

        navItems.forEach { navId ->

            val view = findViewById<View>(navId)

            if (view is ViewGroup) {

                for (i in 0 until view.childCount) {

                    val child = view.getChildAt(i)

                    when (child) {

                        is TextView -> {
                            child.setTextColor(getColor(android.R.color.white))
                        }

                        is ImageView -> {
                            child.setColorFilter(getColor(android.R.color.white))
                            child.alpha = 1f
                        }
                    }
                }
            }
        }
    }

    private fun tintNavigationIcons() {
        listOf(R.id.searchButton, R.id.ordersButton, R.id.cartButton).forEach { id ->
            findViewById<ImageButton>(id).setColorFilter(getColor(android.R.color.white))
        }
        setActiveNav(R.id.navHome)
    }

    private fun handleInitialIntent() {
        if (intent?.getBooleanExtra("open_courier_dashboard", false) == true) {
            loadFragment(com.waserba.kebumen.ui.dashboard.DashboardFragment(), false)
            setActiveNav(R.id.navDashboard)
            return
        }

        loadFragment(HomeFragment(), false)
        setActiveNav(R.id.navHome)
    }

    private fun syncFirebaseToken() {
        val user = PreferencesManager(this).getUserInfo() ?: return
        val userId = user.id_user ?: user.id ?: return

        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            lifecycleScope.launch {
                try {
                    RetrofitClient.apiService.updateFCMToken(userId.toString(), token)
                } catch (_: Exception) {
                    // Firebase will issue onNewToken again when the token changes.
                }
            }
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    // =========================
    // LOGIN DIALOG (READY BUT CLEAN)
    // =========================
    private fun showLoginDialog() {

        val dialogView = layoutInflater.inflate(R.layout.dialog_login, null)

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        val loginTab = dialogView.findViewById<TextView>(R.id.loginTab)
        val registerTab = dialogView.findViewById<TextView>(R.id.registerTab)

        val loginForm = dialogView.findViewById<View>(R.id.loginForm)
        val registerForm = dialogView.findViewById<View>(R.id.registerForm)

        loginTab.setOnClickListener {
            loginForm.visibility = View.VISIBLE
            registerForm.visibility = View.GONE
        }

        registerTab.setOnClickListener {
            loginForm.visibility = View.GONE
            registerForm.visibility = View.VISIBLE
        }

        dialogView.findViewById<View>(R.id.loginButton).setOnClickListener {
            Toast.makeText(this, "Login TODO via ViewModel", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialogView.findViewById<View>(R.id.registerButton).setOnClickListener {
            Toast.makeText(this, "Register TODO", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }
}
